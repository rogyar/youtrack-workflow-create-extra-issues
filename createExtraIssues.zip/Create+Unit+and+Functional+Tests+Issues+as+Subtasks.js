statelessrule("Create Unit and Functional Tests Issues as Subtasks", model.Event.BEFORE_FLUSH, function(ctx) {
  return invoke(ctx, ctx.issue, "becomesReported", []);
}, function(ctx) {
  if (equals(safeCall(ctx.issue,"get", ["Type"]), find("Feature")) || equals(safeCall(ctx.issue,"get", ["Type"]), find("Bug"))) {
    var functionalIssue = invoke(ctx, ctx.loggedInUser, "createNewIssue", [safeCall(safeCall(ctx.issue,"get", ["project"]),"get", ["shortName"], null)]);
    var unitIssue = invoke(ctx, ctx.loggedInUser, "createNewIssue", [safeCall(safeCall(ctx.issue,"get", ["project"]),"get", ["shortName"], null)]);
    safeCall(functionalIssue,"set", ["Type", find("Meta Issue")], null);
    safeCall(functionalIssue,"set", ["summary", "Functional tests for " + safeCall(ctx.issue,"get", ["summary"], null)], null);
    safeCall(functionalIssue,"set", ["description", "Create functional tests for " + invoke(ctx, ctx.issue, "getUrl", [])], null);
    safeCall(safeCall(functionalIssue,"get", ["subtask of"]),"add", [ctx.issue]);
    safeCall(unitIssue,"set", ["Type", find("Meta Issue")], null);
    safeCall(unitIssue,"set", ["summary", "Unit tests for " + safeCall(ctx.issue,"get", ["summary"], null)], null);
    safeCall(unitIssue,"set", ["description", "Create unit tests for " + invoke(ctx, ctx.issue, "getUrl", [])], null);
    safeCall(safeCall(unitIssue,"get", ["subtask of"]),"add", [ctx.issue]);
  }
}).addRequirements(requirements([{name: "Issue", fields: [{name: "project", type: {name: "Project", fields: [{name: "shortName", type: {name: "string", primitive: true}}]}}, {name: "Type", type: {name: "EnumField", values: ["Meta Issue", "Bug", "Feature"]}}, {name: "summary", type: {name: "string", primitive: true}}, {name: "description", type: {name: "string", primitive: true}}, {name: "Subtask", type: {name: "IssueLinkPrototype", multiple: true, fields: [{name: "parent for", type: {name: "Issue", multiple: true}}, {name: "subtask of", type: {name: "Issue", multiple: true}}]}}]}]));